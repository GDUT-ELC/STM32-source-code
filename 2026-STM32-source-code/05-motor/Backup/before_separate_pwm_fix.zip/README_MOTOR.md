# 05-motor 简化速度闭环

当前 A 路目标 **800 CPS**，B 路 **0（停车）**，保留最新的目标修改。
TIM6 每 10ms 执行一次：读取编码器计数差 → 计算速度 → PI → 输出 PWM。
默认 Kd=0，因此实际使用 PI；保留 PID 接口供需要时调参。

## 改目标

打开 `Core/Src/main.c`，修改后重新编译、下载：

```c
#define DEMO_A_TARGET_CPS     800.0f
#define DEMO_B_TARGET_CPS     0.0f
```

正数正转，负数反转，0 制动停车。CPS 是编码器四倍频计数/秒；
200 CPS 对应平均每 10ms 增加 2 个计数，并不是 200 RPM 或 20% PWM。

程序只在初始化后设置一次目标，主循环读取反馈即可。
需要改变速度时调用 `motor_set_target_cps(MOTOR_A, 目标值)`；
需要停车时调用 `motor_stop_all()`。
Watch 中的 `motor_a_feedback` / `motor_b_feedback` 只用于观察，不能通过修改它们下发目标。

## 改 PI 参数

在 `Bsp/motor_config.h` 修改，当前参数：

| 电机 | Kp | Ki | Kd |
| --- | --- | --- | --- |
| A | 0.20 | 1.32 | 0 |
| B | 0.20 | 0.80 | 0 |

误差单位 CPS，输出单位 PWM 千分比，积分时间单位秒。
参数需要结合电机和负载调整；先调 Kp，再加 Ki，Kd 先保持 0。
不要在主循环反复调用 `motor_set_pid()`，它会清空积分。

## 观察结果

Keil 连续运行时查看 `motor_a_feedback`（A）或 `motor_b_feedback`（B）：

| 字段 | 含义 |
| --- | --- |
| `target_cps` | 实际生效目标 |
| `speed_cps` | 编码器测速，经过简单滤波 |
| `delta_counts` | 最近 10ms 的有符号计数差 |
| `pwm` | 输出千分比，300 表示 30% |
| `control_ticks` | 控制执行次数，应约每秒增加 100 |
| `pid_integral` | 积分输出 |

正 PWM 必须对应正的编码器速度。若持续反向，核对接线并修改对应的
`MOTOR_A_ENCODER_SIGN` 或 `MOTOR_B_ENCODER_SIGN`（+1 / -1）。

## 接线与定时器

| 功能 | 引脚 / 配置 |
| --- | --- |
| AIN1 / AIN2 | PD11 / PD10 |
| BIN1 / BIN2 | PD8 / PD9 |
| A 编码器 | PD12 / PD13，TIM4 |
| B 编码器 | PC6 / PC7，TIM3 |
| PWM | TIM2，84MHz / 84000 = 1kHz，GPIO 软件输出 |
| 控制周期 | TIM6，84MHz / 84 / 10000 = 100Hz |

PD8～PD11 没有定时器 PWM 复用，沿用 GPIO PWM。
DRV8848 的输入 01/10 控制方向，11 制动；PWM 关闭阶段和停车使用 11。
1kHz 下普通 PWM 更新最多等一个周期（1ms），停车/换向先立即制动。
软件 PWM 的小占空比仍受中断延迟影响，实际波形需上板测量；1kHz 可能有可听见的声音。
电机驱动电源、编码器电源和共地按实际硬件连接。

## 本次简化

- 删除 TIM5 测间隔及超过 30ms 清积分停车的分支。TIM5 生成代码保留，当前主程序不初始化、不使用。
- 删除新增的反馈故障锁存及 `fault` 等字段。
- 删除 Watch 目标命令数组和同步逻辑，目标统一在 `main.c` 设置。
- 软件 PWM 从 10kHz 改为 1kHz，降低中断负担及相同占空比下的脉冲缩短比例。
- 保留输出限幅、积分抗饱和、目标 0 停车及系统异常制动。

固定周期控制适用于 TIM6 连续运行；不要在控制过程中单步或设置断点来判断速度。
无编码器反馈时 PI 会增大输出直至限幅，这个简化版不再自动锁存停车。
修改前文件保存在 `Backup/before_simple_control_20261113.zip`。

## 编译和验证

打开 `MDK-ARM/5-motor.uvprojx` 编译下载。
固件：`MDK-ARM/5-motor/5-motor.hex`。
编译日志：`MDK-ARM/motor_simple_build.log`。

运行电脑端模拟测试：

```powershell
& ./05-motor/Tests/run_tests.ps1
```

测试包含 200 CPS 正反转、负载变化、超速降输出、停车再启动、编码器回绕、
积分抗饱和和 PWM 比较边沿。编译与模拟测试不能代替实物验证。
其他接口用法见 `Examples/README.md`。
