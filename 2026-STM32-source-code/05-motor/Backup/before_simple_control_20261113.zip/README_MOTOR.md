# DRV8848 双电机编码器速度闭环示例

本工程用于展示 STM32F407VET6 开发板的双电机驱动、正交编码器测速和速度 PID 控制功能。
驱动芯片为 DRV8848PWPR，电机控制接口封装在 `Bsp/motor.h`，应用程序调用接口即可控制两路电机。

当前示例按仅连接 A 电机配置：A 路默认目标为 **200 CPS**，B 路为 **0（制动）**。
初始目标由 `main.c` 的 `DEMO_A_TARGET_CPS` / `DEMO_B_TARGET_CPS` 指定。
Keil 连续运行时可修改 `g_motor_target_cps[0]`（A）或 `[1]`（B），主循环会下发新目标。
CPS 为四倍频编码计数/秒，负目标表示反向，0 表示制动停车。

## 工程结构

| 文件/目录 | 功能 |
| --- | --- |
| `MDK-ARM/5-motor.uvprojx` | Keil 工程，使用 Arm Compiler 6.23 |
| `5-motor.ioc` | CubeMX 引脚、时钟及外设配置 |
| `Core/Src/main.c` | 双电机速度闭环应用示例 |
| `Bsp/motor.h`、`motor.c` | 电机控制接口、编码器反馈、开闭环切换 |
| `Bsp/motor_config.h` | 方向修正、每圈计数、控制周期与 PID 参数 |
| `Bsp/pid.h`、`pid.c` | 独立速度 PID 算法，包含限幅和抗积分饱和 |
| `Bsp/motor_pwm.h`、`motor_pwm.c` | DRV8848 GPIO PWM 底层驱动 |
| `Core/Src/gpio.c`、`tim.c` | GPIO 和定时器初始化 |
| `Core/Src/stm32f4xx_it.c` | TIM2 PWM 与 TIM6 控制节拍中断入口 |
| `Examples/README.md` | 开环、闭环、正反转、停车、反馈读取及 RPM 调用示例 |
| `Drivers/`、启动汇编及 CMSIS 系统文件 | ST 提供的底层依赖 |
| `Tests/` | 电脑端模拟测试，不参与固件编译 |
| `Tools/annotate_functions.py` | 应用函数中文说明维护工具，不参与固件编译 |

## 硬件连接

| 功能 | MCU 引脚/硬件连接 | 配置 |
| --- | --- | --- |
| AIN1 / AIN2 | PD11 / PD10 | A 路驱动输入，GPIO 推挽输出 |
| BIN1 / BIN2 | PD8 / PD9 | B 路驱动输入，GPIO 推挽输出 |
| A 路编码器 | PD12 / PD13 | TIM4_CH1/CH2，AF2，上拉 |
| B 路编码器 | PC6 / PC7 | TIM3_CH1/CH2，AF2，上拉 |
| nSLEEP | 接 VCCT（3.3V） | 硬件常使能，无软件休眠接口 |
| nFAULT | 图中未连接 MCU | 无软件故障读取接口 |
| PB14 / PB15 | 未接驱动 | 本工程未配置为 PWM 输出 |

A 路绕组接 AO1/AO2（P3-1/P3-6），B 路接 BO1/BO2（P4-1/P4-6）。
驱动 VM 接电机电源，MCU 与驱动共地。P3/P4 的电源与地由 0Ω 电阻焊接选择，按实物核对。
编码器信号应与 3.3V 逻辑兼容。

PD8～PD11 没有定时器 PWM 复用功能，因此使用 TIM2 中断修改 GPIO 电平，以适配现有 PCB 接线。
TIM2 的 CH1/CH2 只用于内部比较计时，不连接外部定时器通道引脚。

## 编译与运行

1. 打开 `MDK-ARM/5-motor.uvprojx`，确认使用已安装的 Arm Compiler 6.23。
2. 在 `main.c` 中修改 `DEMO_A_TARGET_CPS` 设置 A 路上电闭环目标；B 路默认未启动。
3. 在 `motor_config.h` 中核对编码器方向、每圈计数及 PID 系数。
4. 编译、下载并给驱动电机电源供电，A 路进入速度闭环。

输出固件为 `MDK-ARM/5-motor/5-motor.hex`，本次 PID 检查编译日志为 `MDK-ARM/motor_pid_fix_build.log`。
上电目标沿用当前工程设置，并非默认停车；需要停车时将目标设为 0，或使用 `motor_stop_all()`。

主程序完成 GPIO、TIM2/3/4/5/6 初始化后，调用一次 `motor_init()`，再发送目标指令。
指令持续有效，无需在主循环反复发送。初始化后切换接口即可切换开闭环模式。
本示例主循环仅在 `g_motor_target_cps[]` 的值变化时下发新命令，避免反复设置目标。
另行调用 `motor_stop()` 或 `motor_set_pwm()` 后不会自动恢复闭环；要从 Watch 重新启动，
将命令先改为 0 再改为所需目标，等待主循环分别接收即可。

## 设置 200 后持续加速的排查

检查时发现原 `main.c` 中启动目标为 A=900、B=100，并不是 200；现在改为 A=200、B=0。
`motor_a_feedback` / `motor_b_feedback` 是主循环读取的**反馈副本**，修改它们的 `target_cps`
不会改变电机目标，下一次读取还会覆盖修改。运行时请修改 `g_motor_target_cps[]`，
或在自己的程序中调用 `motor_set_target_cps()`。`g_motor_feedback[]` 用于观察，不作为调参入口。

在 Keil Watch 中添加以下变量并连续运行（A 路用 `[0]`，B 路用 `[1]`）：

| 变量 | 正常情况 / 用途 |
| --- | --- |
| `g_motor_target_cps[0]` | 可修改的目标命令，例如 `200.0`；设 `0.0` 停车 |
| `g_motor_feedback[0].target_cps` | 实际生效目标，应等于 200 |
| `g_motor_feedback[0].mode` | 1 为闭环；0 为固定 PWM 开环 |
| `g_motor_feedback[0].speed_cps` | 编码器反馈速度，稳定后应接近目标，有计数量化波动 |
| `g_motor_feedback[0].pwm` | PID 输出，千分比；300 为 30%，不是实际速度 |
| `g_motor_feedback[0].pid_integral` | 积分输出；反馈持续高于目标时应逐渐下降 |
| `g_motor_feedback[0].sample_us` | 约 10000，表示采样间隔 10ms |
| `g_motor_feedback[0].control_ticks` | 连续增加表示控制中断在执行 |
| `g_motor_feedback[0].fault` | 0 正常；1 有驱动但无计数；2 反馈方向异常 |

- 生效目标不是 200：先检查目标宏、命令变量和下载的固件，不能据此判断 PID 失效。
- 生效目标为 200，速度高于 200，PWM 和积分下降：PID 正在减速；短时过冲需要结合电机负载整定参数。
- 生效目标为 200，反馈持续高于 200，PWM 已降至 0 或反向，电机仍持续加速：检查 PD10/PD11（A）或 PD8/PD9（B）的实际波形、驱动接线与制动状态。单看反馈无法证明输出波形正确。
- 反馈接近 200，但觉得转得快：200 的单位是 CPS，并不是 200 RPM 或 20% PWM；RPM 还取决于每圈计数。

闭环新增反馈故障停车：输出绝对值至少 200 千分比时，持续 500ms 无编码器计数，
锁存故障 1；目标与 PWM 同向、但反馈速度持续 500ms 反向且绝对值超过 100 CPS，锁存故障 2。
故障后该路输出保持为 0，切换目标/开环也不会恢复，需排除接线或堵转问题后复位。
检测门限在 `motor_config.h`，低速/大惯性电机需结合实物调整。
这两类检测不能诊断所有正向超速问题；若目标为 200 仍持续超速，请记录上表中的目标、速度、PWM、积分和采样间隔。

```mermaid
flowchart TD
    A[main：初始化外设] --> B[motor_init：启动编码器、PWM 和控制节拍]
    B --> C[motor_set_target_cps：设置目标]
    C --> D[主循环处理其他应用任务]
    E[TIM6：每 10ms] --> F[编码器计数差与速度滤波]
    F --> G{当前是否闭环}
    G -->|是| H[PID 计算输出]
    G -->|否| I[保持开环指令]
    H --> J[TIM2：10kHz GPIO PWM]
    I --> J
    J --> K[DRV8848 驱动电机]
```

`HAL_Delay()` 延时主循环时，正常情况下控制中断仍继续运行。不要在中断内延时，也不要长时间屏蔽中断。

## 电机控制接口

完整参数、返回值和调用约束已在 `motor.h` 与对应函数实现前以 Doxygen 格式标注。

| 接口 | 作用 | 关键参数单位 |
| --- | --- | --- |
| `motor_init()` | 初始化并启动两路控制 | 返回 `HAL_OK` 或 `HAL_ERROR` |
| `motor_set_target_cps()` | 设置速度目标并启用闭环 | 四倍频编码计数/秒 |
| `motor_set_target_rpm()` | 设置转速目标并启用闭环 | 输出轴转/分；必须配置每圈计数 |
| `motor_set_pwm()` | 设置固定占空比并切换为开环 | -1000～1000 的千分比 |
| `motor_stop()` | 单路制动，清空目标与积分 | `MOTOR_A` 或 `MOTOR_B` |
| `motor_stop_all()` | 两路制动，清空目标与积分 | 无参数 |
| `motor_get_feedback()` | 读取一致的反馈快照 | 输出 `motor_feedback_t` |
| `motor_set_pid()` | 更新 PID 系数并复位积分 | Kp、Ki、Kd，积分时间单位秒 |

`motor_setspeed1/2()` 是保留的旧版百分比接口，单位为 -100～100；新应用统一使用 `motor_set_pwm()` 的千分比。
`motor_control_tick()` 由 TIM6 回调调用，应用程序不需要手动重复调用。
`motor_pwm_*()` 属于底层驱动接口，应用程序通过 `motor.h` 控制电机即可。

## 编码器与调试观察

| 观察值 | A 路 Watch 表达式 | B 路 Watch 表达式 |
| --- | --- | --- |
| 编码器原始计数 | `htim4.Instance->CNT` | `htim3.Instance->CNT` |
| 最近 10ms 的计数差 | `g_motor_feedback[0].delta_counts` | `g_motor_feedback[1].delta_counts` |
| 实际速度 CPS | `g_motor_feedback[0].speed_cps` | `g_motor_feedback[1].speed_cps` |
| 目标速度 CPS | `g_motor_feedback[0].target_cps` | `g_motor_feedback[1].target_cps` |
| 输出千分比 | `g_motor_feedback[0].pwm` | `g_motor_feedback[1].pwm` |
| 控制模式 | `g_motor_feedback[0].mode` | `g_motor_feedback[1].mode` |
| 控制执行次数 | `g_motor_feedback[0].control_ticks` | `g_motor_feedback[1].control_ticks` |
| 实际采样间隔（us） | `g_motor_feedback[0].sample_us` | `g_motor_feedback[1].sample_us` |
| 超时采样恢复次数 | `g_motor_feedback[0].timing_resets` | `g_motor_feedback[1].timing_resets` |
| 积分输出 | `g_motor_feedback[0].pid_integral` | `g_motor_feedback[1].pid_integral` |

`mode=0` 为开环，`mode=1` 为速度闭环。`speed_rpm` 在每圈计数未配置时为 0，不代表电机没有转动。
`CNT` 范围为 0～65535，支持正反向回绕；`delta_counts` 为有符号增量，不是累计计数，实际间隔见 `sample_us`。
主循环的 `motor_a_feedback`、`motor_b_feedback` 是上述状态的快照。
`pwm` 是有符号 16 位数，Watch 中的 `0xFC18` 为十进制 **-1000**，表示反向满幅。

```text
delta_counts = 20，即 10ms 内增加 20 个计数
speed = 20 / 0.01s = 2000 CPS
pwm = 83，即 8.3% 占空比
```

10ms 测速下，一个计数对应 100 CPS 的原始速度变化。`speed_cps` 已经过低通滤波，应结合一段时间的平均值判断误差。
Watch 观察时保持程序运行；暂停 CPU 会影响软件 PWM 和控制中断。
应用程序读取整组反馈使用 `motor_get_feedback()`，避免读到不同周期拼接的数据。

## 控制周期和驱动逻辑

系统晶振 8MHz，CPU 时钟 168MHz，APB1 定时器时钟 84MHz。

| 定时器 | 用途 | PSC / ARR | 配置 |
| --- | --- | --- | --- |
| TIM2 | 两路 GPIO PWM | 0 / 8399 | 10kHz，100µs；中断优先级 4 |
| TIM3 | B 路编码器 | 0 / 65535 | TI12 四倍频，滤波 6 |
| TIM4 | A 路编码器 | 0 / 65535 | TI12 四倍频，滤波 6 |
| TIM5 | 测量实际采样间隔 | 83 / 4294967295 | 1MHz，自由运行，无引脚、无中断 |
| TIM6 | 两路测速和 PID | 83 / 9999 | 100Hz，10ms；中断优先级 5 |

编码器连续计数，读取前后计数差处理回绕，不在采样时清零；每个有效采样周期的计数绝对值须小于 32768。
测速和 PID 使用 TIM5 实测间隔，正常约 10ms；小于 5ms 的重复回调不执行控制。
间隔超过 30ms 时丢弃该次计数差、清零滤波和积分，闭环制动一次；下一正常采样按原目标恢复，开环保持原输出。
TIM5 不随调试暂停冻结，32 位计数约 71.6 分钟回绕，正常连续采样可处理回绕；不能跨越完整回绕周期推算停顿时长。
调试暂停期间 CPU 无法更新 GPIO，电机输入会停留在暂停瞬间的电平；超时恢复不能替代暂停期间的输出控制。
TIM2 每秒最多约 30000 次中断，GPIO 波形边沿受软件中断延迟影响。
很小的占空比可能因比较时刻已过去而被缩短，因此命令值不等于实测有效占空比，需用示波器验证低速波形。

按 [DRV8848 数据手册](https://www.ti.com/document-viewer/DRV8848/datasheet/GUID-C47EC45F-3531-4ECE-9BC3-E02C4BEC0343)：

| IN1 | IN2 | 状态 |
| --- | --- | --- |
| 0 | 0 | 高阻滑行 |
| 0 | 1 | 一个转向（默认正指令） |
| 1 | 0 | 相反转向 |
| 1 | 1 | 短路制动 |

PWM 关闭阶段与停车均输出 11。换向先立即制动，下个 PWM 周期应用新方向；普通 PWM 更新最多等待约 100µs。

## 参数配置

`Bsp/motor_config.h` 集中保存方向、每圈计数和 PID 参数。
正 PWM 应得到正的编码器速度；方向不一致时先修正 `ENCODER_SIGN`，机械正方向由 `DRIVE_SIGN` 定义。

RPM 换算参数：

```text
输出轴每圈计数 = 电机轴单相每圈脉冲数 × 4 × 减速比
RPM = CPS × 60 / 输出轴每圈计数
```

当前两路 `COUNTS_PER_REV=0` 表示未知，RPM 接口返回 `HAL_ERROR`，CPS 接口正常使用。
单相 11 脉冲、减速比 30:1 时为 1320，仅为换算示例。厂家若已给出四倍频后或输出轴计数，不重复乘系数。

当前 PID：A 路 `0.20 / 1.32 / 0`，B 路 `0.20 / 0.80 / 0`。
Kp 调整误差响应，Ki 消除持续误差，Kd 对实际速度求微分。默认 Kd 为 0。
误差单位 CPS，输出单位千分比，积分时间单位秒。
运行时调用 `motor_set_pid()` 会清空积分，不能在主循环反复调用；静态参数可直接修改配置宏后编译。

## CubeMX 重新生成

1. 打开 `5-motor.ioc`，启用 `Keep User Code` 后生成。
2. 确认 Keil 中保留 `Bsp` 包含路径及 `motor.c`、`motor_pwm.c`、`pid.c`。
3. 工程根目录执行 `python .\Tools\annotate_functions.py` 恢复统一中文函数说明。
4. 重新编译并下载。

目标配置宏、启动指令、TIM6 回调、TIM2 自定义入口均位于 USER CODE 区域。
生成器可能覆盖该区域以外的解释注释，维护脚本用于恢复函数说明与常用中文注释。
独立 Bsp 文件不会被 CubeMX 重写。应用 C/H 文件采用带 BOM 的 UTF-8，便于 Keil/Windows 识别中文。

## 工程检查记录

详细结论、逐项检查范围和本次异常数据分析见 [REVIEW_MOTOR.md](REVIEW_MOTOR.md)。

- 对照最新粘贴代码采用宏设置 A 路目标；保留后续调试修改，B 路保持停车。
- 增加 TIM5 实测采样时间及超时恢复，新增原始计数、控制次数、采样间隔和积分观察值。
- 系统异常和 `Error_Handler()` 直接关闭 PWM 中断并制动，避免软件 PWM 输出停留在驱动态。
- PID 运算增加非有限值检查，RPM 换算溢出返回错误；重复成功初始化不再重启 HAL 通道。
- 修正 PLLQ 为 7，使 48MHz 时钟域正确；CPU 168MHz 和 APB1 定时器 84MHz 保持原配置。
- 电机驱动方向、编码器方向和当前 PID 系数保留，方向需由实测正负 PWM 确认。

此前注释和接口整理：

- 应用层函数定义和声明统一添加中文 `@brief`、`@param`、`@retval`，必要处补充 `@note`。
- `main.c` 保留直接调用封装接口的闭环示例，当前速度目标和 PID 参数保持原值。
- 去掉重复、过时的默认停车示例注释，其他典型调用集中到 `Examples/README.md`。
- TIM2 默认 HAL 分发调用已注释，由 `motor_pwm_irq()` 处理；保留提前返回，兼容再生成后的默认分发代码。
- 两个旧百分比接口保留供兼容，注明与千分比接口的单位差异。
- 删除电脑端模拟头文件中未使用的 `HAL_TIM_PWM_Start()` 声明；实际驱动已经使用 GPIO PWM。
- 保留 CubeMX 标记、启动文件、HAL/CMSIS 依赖；没有删除电机、编码器或 PID 功能。
- 现有 `keilkill.bat` 属于编译清理脚本，不参与示例运行，本次未执行。

## 验证

本次检查的编译与测试结果见 `Tests/verification.log`。
应用与测试的函数定义/声明均使用统一中文说明，CubeMX 再生成后可运行维护工具恢复。

电脑端模拟测试：

```powershell
powershell -ExecutionPolicy Bypass -File .\Tests\run_tests.ps1
```

覆盖 PID 正反向收敛与抗饱和、编码器回绕、两路独立控制、模式切换、停车保持，
以及 999 档 GPIO PWM、比较边沿、换向制动和中断延迟处理。
编译和模拟测试不能替代实物波形、编码器信号及实际负载下的速度响应测试。
