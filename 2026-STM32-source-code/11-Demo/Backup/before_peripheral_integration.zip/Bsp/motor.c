/**********************************************************
 * 文件名: motor.c
 * 作  者: 电子科技协会嵌入式组
 * 日  期: 2026-10-29
 * 
 * 功能说明:
 *   实现电机控制的具体逻辑，通过GPIO引脚控制电机转向，
 *   利用定时器TIM12输出PWM信号调节电机速度
 * 
 * 接口备注:
 *   1. 需确保定时器相关定时器已正确初始化
 *   2. 电机1通过AIN1、AIN2引脚控制方向，使用TIM12_CH1输出PWM
 *   3. 电机2通过BIN1、BIN2引脚控制方向，使用TIM12_CH2输出PWM
 *   4. 速度范围为-99~99，正负值决定转向，绝对值决定PWM占空比
 **********************************************************/

#include "motor.h"
#include "tim.h"

/**
  * @brief  将电机速度限制在TIM12允许的-99~99范围内
  * @param  speed: 待限制的速度值
  * @retval int16_t 限制后的速度值
  */
static int16_t motor_limit_speed(int16_t speed)
{
	if (speed > 99)
	{
		return 99;
	}
	if (speed < -99)
	{
		return -99;
	}

	return speed;
}

/**
  * @brief  设置电机1的转向和速度
  * @param  Speed: 速度值，范围-99~99；正值正转，负值反转，0停止
  * @retval None
  */
void motor_setspeed1(int8_t Speed)
{
	int16_t speed = motor_limit_speed((int16_t)Speed);

	if (speed >= 0)		//如果设置正转的速度值
	{
		HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_RESET);	
		HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_SET);
		__HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_1, (uint32_t)speed);
	}
	else	 //否则，即设置反转的速度值
	{
		HAL_GPIO_WritePin(AIN1_GPIO_Port, AIN1_Pin, GPIO_PIN_SET);	
		HAL_GPIO_WritePin(AIN2_GPIO_Port, AIN2_Pin, GPIO_PIN_RESET);
		__HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_1, (uint32_t)(-speed));
	}
}

/**
  * @brief  设置电机2的转向和速度
  * @param  Speed: 速度值，范围-99~99；正值正转，负值反转，0停止
  * @retval None
  */
void motor_setspeed2(int8_t Speed)
{
	int16_t speed = motor_limit_speed((int16_t)Speed);

	if (speed >= 0)	    //如果设置正转的速度值
	{
		HAL_GPIO_WritePin(BIN1_GPIO_Port, BIN1_Pin, GPIO_PIN_RESET);	
		HAL_GPIO_WritePin(BIN2_GPIO_Port, BIN2_Pin, GPIO_PIN_SET);
		__HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_2, (uint32_t)speed);
	}
	else    //否则，即设置反转的速度值
	{
		HAL_GPIO_WritePin(BIN1_GPIO_Port, BIN1_Pin, GPIO_PIN_SET);	
		HAL_GPIO_WritePin(BIN2_GPIO_Port, BIN2_Pin, GPIO_PIN_RESET);
		__HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_2, (uint32_t)(-speed));
	}
}
